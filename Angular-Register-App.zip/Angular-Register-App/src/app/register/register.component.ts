import { Component, OnInit } from '@angular/core';
import { User } from '../_models';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  model: any = {};
  constructor(
    private router: Router,) { }

  ngOnInit() {
  }

  register(){
    localStorage.setItem('user', JSON.stringify(this.model));
    this.router.navigate(['/userInfo']);
  }

}
